print_weights <-
function() {
	maximumentropy$print_weights();
}

